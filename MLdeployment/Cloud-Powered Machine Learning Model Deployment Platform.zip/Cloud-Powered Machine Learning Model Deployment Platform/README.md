# Cloud-Powered ML Model Deployment (Local Flask Prototype)

This version includes an **Auto Train** page that trains a model from a CSV you upload,
registers it, and stores a JSON Schema derived from your columns.

See `/train` after starting the server.
